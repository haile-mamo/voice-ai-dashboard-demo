"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useParams, useRouter } from "next/navigation";
import { 
  History, CreditCard, Settings, 
  LayoutDashboard, Loader2, PhoneIncoming,
  Users, Plus, ArrowLeft, Phone
} from "lucide-react";

export default function ClientDashboard() {
  const { id } = useParams();
  const router = useRouter();
  const [org, setOrg] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("agents");
  const [isCreating, setIsCreating] = useState(false);

  // Vapi API Key from your .env.local
  const VAPI_KEY = "2a80725b-dcf0-435f-892d-d7a3ce443d6f";

  useEffect(() => {
    async function fetchData() {
      if (!id) return;
      try {
        const { data, error } = await supabase
          .from("organizations")
          .select("*")
          .eq("id", id)
          .maybeSingle();

        if (error) throw error;
        setOrg(data);
      } catch (err) {
        console.error("Fetch Error:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [id]);

  const createVapiAgent = async () => {
    setIsCreating(true);
    try {
      const response = await fetch('https://api.vapi.ai/assistant', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${VAPI_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: `${org?.name || 'Client'} - AI Voice`,
          firstMessage: "Hello, how can I help you today?",
          model: {
            provider: "openai",
            model: "gpt-3.5-turbo",
            messages: [{ role: "system", content: `You are an AI assistant for ${org?.name}. Be professional and helpful.` }]
          },
          voice: "jennifer-playht"
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        alert(`Success! New Agent Created. ID: ${data.id}`);
        console.log("Vapi Agent Data:", data);
      } else {
        alert("Error: " + (data.message || "Vapi connection failed"));
      }
    } catch (err) {
      console.error("Vapi Error:", err);
      alert("Could not connect to Vapi API.");
    } finally {
      setIsCreating(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
    </div>
  );

  if (!org) return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center text-center p-6">
      <div>
        <h2 className="text-2xl font-black mb-4 uppercase italic">Organization Not Found</h2>
        <button onClick={() => router.push('/clients')} className="text-emerald-500 font-bold hover:underline underline-offset-4 uppercase text-xs tracking-widest">
          Back to Clients List
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#050505] text-white flex font-sans">
      
      {/* Sidebar */}
      <aside className="w-72 border-r border-zinc-900 bg-black p-8 flex flex-col gap-10">
        <button onClick={() => router.push('/clients')} className="flex items-center gap-2 text-zinc-500 hover:text-white text-xs font-bold uppercase transition-colors">
          <ArrowLeft size={14} /> Back to Clients
        </button>
        
        <div className="flex items-center gap-4 px-2">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500 flex items-center justify-center font-black text-black text-xl shadow-lg shadow-emerald-500/20">
            {org.name ? org.name[0].toUpperCase() : "O"}
          </div>
          <div className="truncate">
            <span className="font-black text-sm block truncate w-32 uppercase italic tracking-tight">{org.name}</span>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">{org.subscription_status || "Trial"}</span>
          </div>
        </div>

        <nav className="flex flex-col gap-2">
          {[
            { id: "overview", label: "Overview", icon: LayoutDashboard },
            { id: "agents", label: "AI Agents", icon: Users },
            { id: "calls", label: "Call Logs", icon: History },
            { id: "billing", label: "Billing", icon: CreditCard },
            { id: "settings", label: "Settings", icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-4 px-5 py-4 rounded-[1.25rem] transition-all duration-300 ${
                activeTab === item.id ? "bg-zinc-900 text-white shadow-xl" : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900/40"
              }`}
            >
              <item.icon size={18} className={activeTab === item.id ? "text-emerald-400" : ""} />
              <span className="text-sm font-bold tracking-tight">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-12 overflow-y-auto">
        
        {/* Header section always visible */}
        <header className="mb-12 flex justify-between items-center">
          <h2 className="text-4xl font-black uppercase tracking-tighter italic">Console</h2>
          <div className="flex items-center gap-2 bg-zinc-900/50 border border-zinc-800 px-4 py-2 rounded-full">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-300">Live System</span>
          </div>
        </header>

        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl">
            <div className="bg-zinc-900/30 border border-zinc-800 p-10 rounded-[3rem] hover:border-zinc-700 transition-colors">
              <CreditCard className="text-emerald-500 mb-6" size={32} />
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-1">Total Balance</p>
              <h3 className="text-5xl font-black italic tracking-tighter">${org.billing_balance || "0.00"}</h3>
            </div>

            <div className="bg-zinc-900/30 border border-zinc-800 p-10 rounded-[3rem] hover:border-zinc-700 transition-colors">
              <PhoneIncoming className="text-emerald-500 mb-6" size={32} />
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-1">Usage Limit</p>
              <h3 className="text-5xl font-black italic tracking-tighter">{org.usage_limit_minutes || "0"} <span className="text-xl font-medium text-zinc-500 uppercase">min</span></h3>
            </div>

            <div className="bg-zinc-900/30 border border-zinc-800 p-10 rounded-[3rem] hover:border-zinc-700 transition-colors">
              <Phone className="text-emerald-500 mb-6" size={32} />
              <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-1">Active Number</p>
              <h3 className="text-2xl font-black italic tracking-tight truncate">{org.phone_number || "No Number Assigned"}</h3>
            </div>
          </div>
        )}

        {activeTab === "agents" && (
          <div className="max-w-5xl">
            <div className="flex justify-between items-end mb-12">
              <div>
                <h3 className="text-5xl font-black italic tracking-tighter uppercase mb-2">AI Agents</h3>
                <p className="text-zinc-500 font-medium">Create and deploy voice assistants for this organization.</p>
              </div>
              <button 
                onClick={createVapiAgent}
                disabled={isCreating}
                className="bg-white text-black px-8 py-4 rounded-2xl font-black text-sm hover:bg-emerald-500 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-white/5"
              >
                {isCreating ? <Loader2 className="animate-spin text-black" size={18}/> : <Plus size={18} />}
                CREATE NEW AGENT
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6">
              <div className="py-24 border-2 border-dashed border-zinc-900 rounded-[3.5rem] text-center flex flex-col items-center justify-center bg-zinc-900/10">
                <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center mb-6">
                  <Users className="text-zinc-700" size={32} />
                </div>
                <h4 className="text-zinc-400 font-bold text-lg uppercase tracking-widest italic">No Active Agents</h4>
                <p className="text-zinc-600 max-w-sm mt-2 text-sm">
                  Click the button above to link this client to a Vapi voice assistant and start handling calls.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Other Sections Placeholder */}
        {activeTab !== "overview" && activeTab !== "agents" && (
          <div className="py-24 border-2 border-dashed border-zinc-900 rounded-[3.5rem] text-center flex flex-col items-center justify-center bg-zinc-900/10 max-w-5xl">
            <h4 className="text-2xl font-black italic uppercase tracking-widest text-zinc-500">Section: {activeTab}</h4>
            <p className="text-zinc-600 mt-2 font-medium">This interface component is ready for backend integration.</p>
          </div>
        )}
      </main>
    </div>
  );
}