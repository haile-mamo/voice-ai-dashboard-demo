"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Link from "next/link";
import { 
  Plus, 
  Trash2, 
  ArrowLeft,
  Loader2,
  ShieldCheck,
  ShieldAlert,
  Send
} from "lucide-react";

export default function ClientManagement() {
  const [orgs, setOrgs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [inviteEmail, setInviteEmail] = useState<{ [key: string]: string }>({});
  
  const [form, setForm] = useState({
    name: "",
    brand_color: "#10b981",
    logo_url: "",
    active_ai_provider: "vapi",
    can_manage_agents: true
  });

  useEffect(() => {
    fetchOrgs();
  }, []);

  async function fetchOrgs() {
    const { data } = await supabase.from("organizations").select("*").order('created_at', { ascending: false });
    if (data) setOrgs(data);
    setLoading(false);
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return;
    const { error } = await supabase.from("organizations").insert([form]);
    if (!error) {
      setForm({ name: "", brand_color: "#10b981", logo_url: "", active_ai_provider: "vapi", can_manage_agents: true });
      fetchOrgs();
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this organization?")) {
      await supabase.from("organizations").delete().eq("id", id);
      fetchOrgs();
    }
  };

  const handleInvite = async (orgId: string) => {
    const email = inviteEmail[orgId];
    if (!email) return;

    try {
      const response = await fetch('/api/invite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, orgId }),
      });

      const result = await response.json();
      if (response.ok) {
        alert("Invitation sent successfully!");
        setInviteEmail({ ...inviteEmail, [orgId]: "" });
      } else {
        alert("Error: " + result.error);
      }
    } catch (err) {
      alert("Failed to send invitation.");
    }
  };

  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="animate-spin text-zinc-500" /></div>;

  return (
    <div className="min-h-screen bg-[#050505] text-white p-8 md:p-12">
      <div className="max-w-6xl mx-auto">
        
        {/* Navigation */}
        <div className="flex items-center justify-between mb-12">
          <Link href="/dashboard" className="flex items-center text-zinc-500 hover:text-white transition-all group">
            <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Dashboard
          </Link>
          <div className="bg-zinc-900/50 px-4 py-2 rounded-xl border border-zinc-800 text-[10px] font-bold text-zinc-400 tracking-widest uppercase">
            Super Admin
          </div>
        </div>

        <header className="mb-12">
          <h1 className="text-4xl font-black tracking-tight">Client Management</h1>
          <p className="text-zinc-500 mt-2">Create and manage multi-tenant white-label organizations.</p>
        </header>

        {/* Add New Client Form */}
        <section className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-[2rem] mb-12">
          <h2 className="text-lg font-bold mb-6 flex items-center gap-2"><Plus size={20} /> Register New Client</h2>
          <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2">Org Name</label>
              <input 
                required
                value={form.name}
                onChange={e => setForm({...form, name: e.target.value})}
                className="w-full bg-black border border-zinc-800 p-3 rounded-xl focus:border-zinc-500 outline-none"
                placeholder="Business Name"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2">Logo URL</label>
              <input 
                value={form.logo_url}
                onChange={e => setForm({...form, logo_url: e.target.value})}
                className="w-full bg-black border border-zinc-800 p-3 rounded-xl focus:border-zinc-500 outline-none"
                placeholder="https://..."
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2">Brand Color</label>
              <div className="flex gap-2">
                <input type="color" value={form.brand_color} onChange={e => setForm({...form, brand_color: e.target.value})} className="h-12 w-12 bg-transparent cursor-pointer" />
                <input value={form.brand_color} onChange={e => setForm({...form, brand_color: e.target.value})} className="flex-1 bg-black border border-zinc-800 p-3 rounded-xl font-mono text-sm" />
              </div>
            </div>
            <div className="lg:col-span-3 flex items-center justify-between pt-4 border-t border-zinc-800">
               <label className="flex items-center gap-2 cursor-pointer">
                 <input type="checkbox" checked={form.can_manage_agents} onChange={e => setForm({...form, can_manage_agents: e.target.checked})} className="w-4 h-4 accent-blue-500" />
                 <span className="text-sm text-zinc-400">Enable Agent Management</span>
               </label>
               <button type="submit" className="bg-white text-black px-8 py-3 rounded-xl font-bold hover:bg-zinc-200 transition-all uppercase text-xs tracking-widest">
                 Create Org
               </button>
            </div>
          </form>
        </section>

        {/* Clients List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {orgs.map((org) => (
            <div key={org.id} className="bg-zinc-900/20 border border-zinc-800 p-6 rounded-3xl hover:border-zinc-700 transition-all group relative">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  {org.logo_url ? (
                    <img src={org.logo_url} className="w-12 h-12 rounded-xl object-contain bg-white p-1" alt="logo" />
                  ) : (
                    <div style={{ backgroundColor: org.brand_color }} className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-black text-xl">
                      {org.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h3 className="font-bold text-xl">{org.name}</h3>
                    <p className="text-zinc-500 text-[10px] font-mono uppercase truncate w-32">{org.id}</p>
                  </div>
                </div>
                <button onClick={() => handleDelete(org.id)} className="text-zinc-700 hover:text-red-500 transition-colors">
                  <Trash2 size={18} />
                </button>
              </div>

              {/* Invite User Section */}
              <div className="mb-6 p-4 bg-black/40 rounded-2xl border border-zinc-800/50">
                <p className="text-[9px] text-zinc-500 uppercase font-bold mb-2 tracking-widest">Invite Client Admin</p>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    placeholder="client@email.com"
                    value={inviteEmail[org.id] || ""}
                    onChange={(e) => setInviteEmail({ ...inviteEmail, [org.id]: e.target.value })}
                    className="flex-1 bg-zinc-950 border border-zinc-800 p-2 rounded-lg text-xs outline-none focus:border-zinc-600"
                  />
                  <button 
                    onClick={() => handleInvite(org.id)}
                    className="bg-zinc-800 hover:bg-white hover:text-black p-2 rounded-lg transition-all"
                  >
                    <Send size={14} />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-black/40 p-3 rounded-2xl border border-zinc-800/50">
                  <p className="text-[9px] text-zinc-500 uppercase font-bold mb-1">Provider</p>
                  <p className="text-sm font-bold uppercase text-blue-400">{org.active_ai_provider}</p>
                </div>
                <div className="bg-black/40 p-3 rounded-2xl border border-zinc-800/50 text-right">
                  <p className="text-[9px] text-zinc-500 uppercase font-bold mb-1">Permissions</p>
                  <div className="flex items-center justify-end gap-1">
                    {org.can_manage_agents ? <ShieldCheck size={14} className="text-green-500" /> : <ShieldAlert size={14} className="text-red-500" />}
                    <span className="text-[10px] font-bold">{org.can_manage_agents ? "AGENT ACCESS" : "LOCKED"}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-zinc-800/50">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: org.brand_color }}></div>
                  <span className="text-xs text-zinc-400 font-mono tracking-tighter">{org.brand_color}</span>
                </div>
                <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">
                  Created: {new Date(org.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}