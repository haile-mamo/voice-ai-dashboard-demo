import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { email, orgId } = await request.json();

    // Initialize Supabase Admin using Secret Service Role Key
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY! 
    );

    // 1. Send an invitation email via Supabase Auth Admin API
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'}/auth/confirm`,
      data: { organization_id: orgId }
    });

    if (authError) throw authError;

    // 2. Link the invited user to the specific organization in your DB
    const { error: dbError } = await supabaseAdmin
      .from('organization_users')
      .insert({
        org_id: orgId,
        user_id: authData.user.id,
        email: email,
        role: 'admin'
      });

    if (dbError) throw dbError;

    return NextResponse.json({ success: true, message: 'Invitation sent' });
  } catch (error: any) {
    console.error("Invite Error:", error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}