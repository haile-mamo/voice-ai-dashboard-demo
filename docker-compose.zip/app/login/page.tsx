"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import { Loader2, Mail, Lock } from "lucide-react";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authError) {
      setError("Invalid login credentials");
      setLoading(false);
      return;
    }

    const user = authData.user;

    const { data: userOrg, error: orgError } = await supabase
      .from("organization_users")
      .select("org_id, role")
      .eq("user_id", user.id)
      .single();

    if (userOrg) {
      if (userOrg.role === 'super_admin') {
        router.push("/dashboard/admin");
      } else {
        router.push(`/dashboard/${userOrg.org_id}`);
      }
    } else {
      router.push("/dashboard");
    }

    router.refresh();
  };

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-zinc-900/50 border border-zinc-800 p-8 rounded-3xl shadow-2xl">
        <h1 className="text-3xl font-black mb-2 text-center tracking-tight">Login</h1>
        <p className="text-zinc-500 text-center text-sm mb-8">Access your AI Voice dashboard</p>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2 tracking-widest">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 w-4 h-4" />
              <input 
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full bg-black border border-zinc-800 p-4 pl-12 rounded-2xl focus:border-white outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2 tracking-widest">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 w-4 h-4" />
              <input 
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-black border border-zinc-800 p-4 pl-12 rounded-2xl focus:border-white outline-none transition-all"
              />
            </div>
          </div>

          <button 
            disabled={loading}
            type="submit" 
            className="w-full bg-white text-black font-bold py-4 rounded-2xl hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin w-5 h-5" />
                <span>Signing in...</span>
              </>
            ) : (
              "Sign In"
            )}
          </button>
        </form>

        {error && (
          <div className="text-center mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl">
            <p className="text-red-500 text-sm mb-2">{error}</p>
            <Link 
              href="/forgot-password" 
              className="text-xs text-zinc-400 hover:text-white underline transition-colors"
            >
              Forgot your password?
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}