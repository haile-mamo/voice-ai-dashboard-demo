"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useParams } from "next/navigation";
import { 
  Phone, History, CreditCard, Settings, 
  LayoutDashboard, Loader2, PhoneIncoming,
  Activity, ArrowUpRight, Save, X, PhoneCall,
  Trash2, Link2
} from "lucide-react";

function DirectCallSection({ assistantId }: { assistantId: string }) {
  const [testNumber, setTestNumber] = useState("");
  const [callLoading, setCallLoading] = useState(false);

  const makeCall = async () => {
    if (!testNumber || !assistantId) {
      alert("Please enter a phone number and ensure an agent is selected.");
      return;
    }
    setCallLoading(true);
    try {
      const res = await fetch("/api/vapi/make-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber: testNumber, assistantId }),
      });
      const result = await res.json();
      if (result.success) alert("Call started successfully!");
      else alert("Call Error: " + result.error);
    } catch (err) {
      alert("Connection failed.");
    } finally {
      setCallLoading(false);
    }
  };

  return (
    <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl p-8 shadow-xl mt-8">
      <h3 className="text-sm font-bold mb-4 uppercase flex items-center gap-2 text-emerald-500">
        <PhoneCall size={16} /> Direct Test Call
      </h3>
      <div className="flex flex-col md:flex-row gap-4">
        <input 
          type="text" 
          value={testNumber} 
          onChange={(e) => setTestNumber(e.target.value)} 
          placeholder="+251..." 
          className="flex-1 bg-black border border-zinc-800 px-4 py-4 rounded-2xl text-sm outline-none focus:border-white transition-all text-white" 
        />
        <button 
          onClick={makeCall} 
          disabled={callLoading} 
          className="bg-white text-black px-8 py-4 rounded-2xl text-xs font-black uppercase hover:bg-zinc-200 transition-all flex items-center justify-center gap-2"
        >
          {callLoading ? <Loader2 size={16} className="animate-spin" /> : "Start Call"}
        </button>
      </div>
    </div>
  );
}

export default function ClientDashboard() {
  const { id } = useParams();
  const [org, setOrg] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [updateLoading, setUpdateLoading] = useState(false);
  const [paymentLoading, setPaymentLoading] = useState(false);

  const [totalCalls, setTotalCalls] = useState(0);
  const [calls, setCalls] = useState<any[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [vapiAssistants, setVapiAssistants] = useState<any[]>([]);

  const [showAgentModal, setShowAgentModal] = useState(false);
  const [isCreatingAgent, setIsCreatingAgent] = useState(false);
  const [newAgent, setNewAgent] = useState({ 
    name: "", 
    role: "", 
    prompt: "", 
    firstMessage: "", 
    voice: "Emma" 
  });

  const [logoUrl, setLogoUrl] = useState("");
  const [brandColor, setBrandColor] = useState("");

  useEffect(() => {
    async function fetchData() {
      if (!id) return;

      const { data: orgData, error } = await supabase
        .from("organizations")
        .select("*") 
        .eq("id", id)
        .single();

      if (orgData) {
        setOrg(orgData);
        setLogoUrl(orgData.logo_url || "");
        setBrandColor(orgData.brand_color || "#10b981");
      }

      const { count } = await supabase
        .from('calls')
        .select('*', { count: 'exact', head: true })
        .eq('org_id', id);
      
      setTotalCalls(count || 0);

      const { data: callLogs } = await supabase
        .from("calls")
        .select("*")
        .eq("org_id", id)
        .order("created_at", { ascending: false });

      if (callLogs) setCalls(callLogs);

      const { data: agentsData } = await supabase
        .from("agents")
        .select("*")
        .eq("org_id", id);
      
      if (agentsData) setAgents(agentsData);

      try {
        const vapiRes = await fetch("/api/vapi/get-assistants");
        const vapiData = await vapiRes.json();
        if (Array.isArray(vapiData)) setVapiAssistants(vapiData);
      } catch (err) {
        console.error("Failed to fetch Vapi assistants:", err);
      }

      setLoading(false);
    }
    
    fetchData();
  }, [id]);

  const handleAddCredits = async () => {
    setPaymentLoading(true);
    try {
      const orgIdFromUrl = window.location.pathname.split('/')[2]; 

      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          orgId: orgIdFromUrl || id, 
          amount: 10, 
          orgName: org?.name || "User Organization"
        }),
      });

      const data = await res.json();
      if (data.url) {
        window.location.href = data.url; 
      } else {
        console.error("Payment Error:", data.error);
        alert("Payment Error: " + (data.error || "Could not initiate checkout."));
      }
    } catch (err) {
      alert("Connection failed.");
    } finally {
      setPaymentLoading(false);
    }
  };

  const handleLinkAssistant = async (assistantId: string) => {
    const phoneId = org?.vapi_phone_number_id || org?.phone_number_id;
    if (!assistantId || !phoneId) {
      alert("Error: Missing Phone ID or Assistant ID");
      return;
    }
    setUpdateLoading(true);
    try {
      const res = await fetch("/api/vapi/link-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orgId: id, assistantId, phoneId: phoneId }),
      });
      if (res.ok) {
        setOrg({ ...org, vapi_assistant_id: assistantId });
        alert("Success: Agent linked to phone number!");
      } else {
        const result = await res.json();
        alert("Error: " + result.error);
      }
    } catch (err) { alert("Connection lost"); } finally { setUpdateLoading(false); }
  };

  const handleUpdateSettings = async () => {
    setUpdateLoading(true);
    const updateData = { logo_url: logoUrl, brand_color: brandColor };
    const { error } = await supabase.from("organizations").update(updateData).eq("id", id);
    if (error) alert("Update failed: " + error.message);
    else {
      setOrg((prev: any) => ({ ...prev, logo_url: logoUrl, brand_color: brandColor }));
      alert("Settings saved successfully!");
    }
    setUpdateLoading(false);
  };

  const handleCreateAgent = async () => {
    if (!newAgent.name || !newAgent.prompt) {
      alert("Please fill Name and Prompt");
      return;
    }
    setIsCreatingAgent(true);
    try {
      const res = await fetch("/api/vapi/create-agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...newAgent, systemPrompt: newAgent.prompt, voiceId: newAgent.voice, orgId: id }),
      });
      if (res.ok) {
        alert("Agent created successfully!");
        setShowAgentModal(false);
        window.location.reload();
      } else {
        const errData = await res.json();
        alert("Error: " + errData.error);
      }
    } catch (err) { alert("Server connection failed."); } finally { setIsCreatingAgent(false); }
  };

  const handleDeleteAgent = async (agentId: string) => {
    if (!confirm("Are you sure you want to delete this agent?")) return;
    const { error } = await supabase.from("agents").delete().eq("id", agentId);
    if (error) alert("Delete failed: " + error.message);
    else {
      setAgents(agents.filter(a => a.id !== agentId));
      alert("Agent deleted.");
    }
  };

  const handleDeleteCall = async (callId: string) => {
    if (!confirm("Are you sure you want to delete this call log?")) return;
    const { error } = await supabase.from("calls").delete().eq("id", callId);
    if (error) alert("Delete failed: " + error.message);
    else {
      setCalls(calls.filter(c => c.id !== callId));
      alert("Call log deleted.");
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-white animate-spin" />
    </div>
  );

  const currentThemeColor = org?.brand_color || "#10b981";

  return (
    <div className="min-h-screen bg-black text-white flex">
      <aside className="w-64 border-r border-zinc-800 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3 px-2">
          {org?.logo_url ? (
            <img src={org.logo_url} alt="Logo" className="w-8 h-8 object-contain rounded-md" />
          ) : (
            <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-black text-xs transition-colors" style={{backgroundColor: currentThemeColor}}>
              {org?.name?.[0] || "A"}
            </div>
          )}
          <span className="font-bold text-sm tracking-tight truncate">{org?.name}</span>
        </div>
        <nav className="flex flex-col gap-2">
          {[
            { id: "overview", label: "Overview", icon: LayoutDashboard },
            { id: "agents", label: "AI Agents", icon: PhoneIncoming },
            { id: "calls", label: "Call Logs", icon: History },
            { id: "billing", label: "Billing", icon: CreditCard },
            { id: "settings", label: "Settings", icon: Settings },
          ].map((item) => (
            <button key={item.id} onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === item.id ? "bg-zinc-900 text-white" : "text-zinc-500 hover:text-white"}`}>
              <item.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 p-8 overflow-y-auto relative">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-2xl font-black tracking-tight uppercase">Dashboard</h2>
            <p className="text-zinc-500 text-xs">Real-time Voice AI Analytics</p>
          </div>
          <div className="bg-zinc-900 border border-zinc-800 px-4 py-2 rounded-xl flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">System Live</span>
          </div>
        </header>

        {activeTab === "overview" && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <CreditCard className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Credit Balance</p>
                  <p className="text-2xl font-black">${org?.balance || '0.00'}</p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <PhoneIncoming className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Total Calls</p>
                  <p className="text-2xl font-black">{totalCalls.toLocaleString()}</p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <p className="text-[10px] font-bold text-zinc-500 uppercase mb-2 tracking-widest flex items-center gap-2"><Link2 size={12}/> Linked Agent</p>
                  <select value={org?.vapi_assistant_id || ""} onChange={(e) => handleLinkAssistant(e.target.value)} className="w-full bg-black border border-zinc-800 p-2 rounded-lg text-xs outline-none focus:border-white text-white">
                    <option value="">-- Select Agent --</option>
                    {vapiAssistants.map((va) => <option key={va.id} value={va.id}>{va.name || "Unnamed Agent"}</option>)}
                  </select>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <Phone className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Active Number</p>
                  <p className="text-xl font-black" style={{color: currentThemeColor}}>{org?.phone_number || "No Number"}</p>
                </div>
            </div>
            <DirectCallSection assistantId={org?.vapi_assistant_id || agents[0]?.vapi_assistant_id || ""} />
          </div>
        )}

        {activeTab === "agents" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold uppercase tracking-tight">AI Staffing</h3>
                <p className="text-zinc-500 text-xs">Configure and deploy your voice assistants.</p>
              </div>
              <button onClick={() => { setNewAgent({ name: "", role: "", prompt: "", firstMessage: "", voice: "Emma" }); setShowAgentModal(true); }}
                className="bg-white text-black px-6 py-2 rounded-xl text-sm font-bold hover:bg-zinc-200 transition-all">
                + Create New Agent
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {agents.map((agent) => (
                <div key={agent.id} className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl border-t-2 relative group" style={{borderColor: currentThemeColor}}>
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 bg-zinc-800 rounded-xl flex items-center justify-center text-zinc-400 text-xs font-bold uppercase">
                      <Phone className="w-5 h-5" />
                    </div>
                    <button onClick={() => handleDeleteAgent(agent.id)} className="p-1.5 text-zinc-600 hover:text-red-500 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <h4 className="font-bold text-lg mb-1">{agent.name}</h4>
                  <p className="text-zinc-500 text-[10px] uppercase tracking-widest mb-4 font-bold">{agent.role || "Assistant"}</p>
                  <div className="flex gap-2">
                    <button onClick={() => { setNewAgent({ name: agent.name, role: agent.role || "", prompt: agent.system_prompt || "", firstMessage: agent.first_message || "", voice: agent.voice_id || "Emma" }); setShowAgentModal(true); }}
                      className="flex-1 bg-zinc-800 hover:bg-zinc-700 py-3 rounded-xl text-xs font-bold transition-all">Edit</button>
                    <button onClick={() => handleLinkAssistant(agent.vapi_assistant_id)}
                      className={`p-3 rounded-xl transition-all ${org?.vapi_assistant_id === agent.vapi_assistant_id ? "bg-emerald-500 text-black" : "bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500"}`}
                      style={{backgroundColor: org?.vapi_assistant_id === agent.vapi_assistant_id ? currentThemeColor : ''}}
                    >
                      <Link2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "calls" && (
          <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead className="bg-zinc-900/60 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                <tr>
                  <th className="p-4 border-b border-zinc-800">Status</th>
                  <th className="p-4 border-b border-zinc-800">Date</th>
                  <th className="p-4 border-b border-zinc-800">Duration</th>
                  <th className="p-4 border-b border-zinc-800">Cost</th>
                  <th className="p-4 border-b border-zinc-800">Recording</th>
                  <th className="p-4 border-b border-zinc-800 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {calls.map((call) => {
                  const totalSeconds = Math.round(Number(call.duration_seconds) || 0);
                  const mins = Math.floor(totalSeconds / 60);
                  const secs = totalSeconds % 60;
                  return (
                    <tr key={call.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/20 transition-all">
                      <td className="p-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${call.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                          {call.status}
                        </span>
                      </td>
                      <td className="p-4 text-zinc-400">{new Date(call.created_at).toLocaleDateString()}</td>
                      <td className="p-4 font-mono text-white">{totalSeconds > 0 ? `${mins > 0 ? `${mins}m ` : ""}${secs}s` : "0s"}</td>
                      <td className="p-4 font-bold text-green-500">${(Number(call.cost) || 0).toFixed(2)}</td>
                      <td className="p-4">
                        {call.recording_url ? (
                          <audio controls className="h-8 w-48 opacity-80 hover:opacity-100 transition-all">
                            <source src={call.recording_url} type="audio/mpeg" />
                          </audio>
                        ) : (
                          <span className="text-zinc-600 text-[10px] uppercase font-bold tracking-tight">Processing...</span>
                        )}
                      </td>
                      <td className="p-4 text-right">
                        <button onClick={() => handleDeleteCall(call.id)} className="p-2 text-zinc-600 hover:text-red-500 transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {calls.length === 0 && <div className="p-10 text-center text-zinc-500">No call logs found.</div>}
          </div>
        )}

        {activeTab === "billing" && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-between items-end">
              <div>
                <h3 className="text-xl font-bold uppercase tracking-tight">Billing & Credits</h3>
                <p className="text-zinc-500 text-xs">Manage your usage and payments</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2 bg-zinc-900/40 border border-zinc-800 rounded-[32px] p-10 flex flex-col items-center justify-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1" style={{backgroundColor: currentThemeColor}}></div>
                <CreditCard className="w-10 h-10 mb-6 text-zinc-600" />
                <p className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-2">Available Balance</p>
                <div className="flex items-baseline gap-2 mb-8">
                  <span className="text-6xl font-black">${org?.balance || '0.00'}</span>
                  <span className="text-zinc-500 font-bold">USD</span>
                </div>
                
                <div className="flex gap-4 w-full max-w-sm mb-8">
                  <div className="flex-1 bg-black/40 border border-zinc-800/50 p-4 rounded-2xl flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <span className="text-[10px] font-bold uppercase text-zinc-400">Pay-as-you-go</span>
                  </div>
                  <div className="flex-1 bg-black/40 border border-zinc-800/50 p-4 rounded-2xl flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <span className="text-[10px] font-bold uppercase text-zinc-400">No Monthly Fees</span>
                  </div>
                </div>

                <button 
                  onClick={handleAddCredits}
                  disabled={paymentLoading}
                  className="w-full max-w-sm py-5 rounded-2xl font-black uppercase text-sm flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-lg text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{ backgroundColor: "#2563eb" }}
                >
                  {paymentLoading ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <>
                      <CreditCard size={18} /> Add $10.00 Credits
                    </>
                  )}
                </button>
                <p className="mt-6 text-[10px] text-zinc-600 flex items-center gap-2 uppercase font-bold tracking-widest">
                  🔒 Secure Encrypted Payment via Stripe
                </p>
              </div>

              <div className="space-y-6">
                <div className="bg-zinc-900/40 border border-zinc-800 rounded-[32px] p-8 relative">
                  <div className="absolute top-8 left-0 w-1 h-6 rounded-r-full" style={{backgroundColor: "#2563eb"}}></div>
                  <h4 className="font-bold mb-4">Pricing Details</h4>
                  <p className="text-zinc-400 text-sm leading-relaxed">
                    Adding <span className="text-white font-bold">$10.00</span> will give you roughly <span className="text-white font-bold">60 minutes</span> of high-quality AI voice interaction.
                  </p>
                  <div className="mt-8 pt-8 border-t border-zinc-800">
                    <p className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Questions?</p>
                    <p className="text-zinc-400 text-xs">Contact support for custom enterprise volume pricing.</p>
                  </div>
                </div>
                <div className="bg-zinc-900/20 border border-zinc-800/50 border-dashed rounded-[32px] p-8">
                  <p className="text-zinc-500 text-xs leading-relaxed italic text-center">
                    "Credits never expire and are applied instantly to your account after a successful transaction."
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="max-w-2xl space-y-8">
            <div className="space-y-8 bg-zinc-900/40 border border-zinc-800 rounded-3xl p-8">
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-4 tracking-widest">Organization Preview</label>
                <div className="flex items-center gap-3 px-2 p-4 bg-black/40 rounded-2xl border border-zinc-800/50 w-fit">
                  {logoUrl ? <img src={logoUrl} alt="Logo" className="w-8 h-8 object-contain rounded-md" /> : <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-black text-xs transition-colors" style={{ backgroundColor: brandColor || "#10b981" }}>{org?.name ? org.name[0] : "O"}</div>}
                  <span className="font-bold text-sm tracking-tight truncate">{org?.name || "Organization Name"}</span>
                </div>
              </div>
              <hr className="border-zinc-800" />
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2 tracking-widest">Logo URL</label>
                  <input type="text" value={logoUrl} onChange={(e) => setLogoUrl(e.target.value)} className="w-full bg-black border border-zinc-800 p-4 rounded-2xl outline-none focus:border-white text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-2 tracking-widest">Brand Color</label>
                  <div className="flex gap-4">
                    <input type="color" value={brandColor} onChange={(e) => setBrandColor(e.target.value)} className="w-12 h-12 bg-transparent border-none cursor-pointer rounded-lg" />
                    <input type="text" value={brandColor} onChange={(e) => setBrandColor(e.target.value)} className="flex-1 bg-black border border-zinc-800 p-4 rounded-2xl text-sm font-mono uppercase text-zinc-400" />
                  </div>
                </div>
                <button onClick={handleUpdateSettings} disabled={updateLoading} className="w-full bg-white text-black font-bold py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all">
                  {updateLoading ? <Loader2 size={18} className="animate-spin" /> : <><Save size={16}/> Save Branding</>}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {showAgentModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-800 w-full max-w-lg rounded-[32px] p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1" style={{backgroundColor: currentThemeColor}}></div>
            <button onClick={() => setShowAgentModal(false)} className="absolute top-6 right-6 text-zinc-500 hover:text-white">
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-2xl font-black mb-2 uppercase tracking-tight">Agent Configuration</h3>
            <div className="space-y-5">
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Agent Name</label>
                <input value={newAgent.name} placeholder="Agent Name" className="w-full bg-black border border-zinc-800 p-4 rounded-2xl text-sm outline-none focus:border-white" onChange={(e) => setNewAgent({...newAgent, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Role/Job Title</label>
                <input value={newAgent.role} placeholder="Medical Receptionist" className="w-full bg-black border border-zinc-800 p-4 rounded-2xl text-sm outline-none focus:border-white" onChange={(e) => setNewAgent({...newAgent, role: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">First Greeting Message</label>
                <input value={newAgent.firstMessage} placeholder="How can I help you today?" className="w-full bg-black border border-zinc-800 p-4 rounded-2xl text-sm outline-none focus:border-white" onChange={(e) => setNewAgent({...newAgent, firstMessage: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Behavior Instructions</label>
                <textarea value={newAgent.prompt} placeholder="Instructions..." className="w-full bg-black border border-zinc-800 p-4 rounded-2xl h-32 text-sm outline-none focus:border-white resize-none" onChange={(e) => setNewAgent({...newAgent, prompt: e.target.value})} />
              </div>
              <div className="pt-4 flex gap-3">
                <button onClick={() => setShowAgentModal(false)} className="flex-1 bg-zinc-900 py-4 rounded-2xl font-bold hover:bg-zinc-800 transition-all">Cancel</button>
                <button onClick={handleCreateAgent} disabled={isCreatingAgent} className="flex-1 bg-white text-black py-4 rounded-2xl font-bold hover:bg-zinc-200 transition-all">
                  {isCreatingAgent ? <Loader2 className="animate-spin mx-auto" /> : "Save Agent"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}