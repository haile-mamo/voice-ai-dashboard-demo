"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Link from "next/link";
import { 
  LayoutDashboard, 
  Mic2, 
  Phone, 
  CreditCard, 
  Settings, 
  Users,
  Loader2,
  TrendingUp,
  ArrowUpRight,
  Activity
} from "lucide-react";

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [orgData, setOrgData] = useState<any>(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const { data, error } = await supabase
          .from("organizations")
          .select("*")
          .limit(1);
        
        if (data && data.length > 0) {
          setOrgData(data[0]);
        }
      } catch (err) {
        console.error("Dashboard error:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const brandColor = orgData?.brand_color || "#2563eb";

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <Loader2 className="animate-spin text-blue-600" size={40} />
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white flex font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-64 border-r border-zinc-800 p-6 fixed h-full bg-black flex flex-col z-50">
        <div className="mb-12 flex items-center gap-3 px-2">
          {orgData?.logo_url ? (
            <img src={orgData.logo_url} alt="Logo" className="w-9 h-9 rounded-xl object-contain bg-white p-1.5 shadow-lg shadow-white/5" />
          ) : (
            <div style={{ backgroundColor: brandColor }} className="w-9 h-9 rounded-xl flex items-center justify-center text-black font-black shadow-lg shadow-blue-500/10">
              {orgData?.name?.charAt(0) || "S"}
            </div>
          )}
          <div className="flex flex-col">
            <span className="font-black text-lg leading-none tracking-tighter">STEPHEN</span>
            <span className="text-[10px] text-zinc-500 font-bold tracking-[0.2em] uppercase">Intelligence</span>
          </div>
        </div>
        
        <nav className="space-y-1.5 flex-1">
          <Link href="/dashboard" className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-zinc-900 text-white transition-all font-semibold shadow-sm border border-zinc-800">
            <LayoutDashboard size={18} /> Dashboard
          </Link>
          
          <Link href="/dashboard/agents" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-zinc-900/50 transition-all font-semibold">
            <Mic2 size={18} /> AI Agents
          </Link>

          <Link href="/dashboard/calls" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-zinc-900/50 transition-all font-semibold">
            <Phone size={18} /> Call Logs
          </Link>

          <Link href="/dashboard/admin" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-zinc-900/50 transition-all font-semibold">
            <Users size={18} /> Clients
          </Link>
          
          <Link href="/dashboard/billing" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-zinc-900/50 transition-all font-semibold">
            <CreditCard size={18} /> Billing
          </Link>
        </nav>

        <div className="mt-auto pt-6 border-t border-zinc-800">
          <Link href="/dashboard/settings" className="flex items-center gap-3 px-4 py-3 rounded-2xl text-zinc-400 hover:text-white hover:bg-zinc-900/50 transition-all font-semibold">
            <Settings size={18} /> Settings
          </Link>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="ml-64 p-12 w-full bg-[#050505]">
        <header className="mb-14 flex justify-between items-end">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse"></span>
              <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">System Overview</p>
            </div>
            <h1 className="text-5xl font-black tracking-tighter">Welcome Back!</h1>
          </div>
          <div className="flex gap-3">
             <div className="bg-zinc-900/50 border border-zinc-800 px-4 py-2 rounded-2xl flex items-center gap-2">
               <Activity size={14} className="text-blue-500" />
               <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Live Latency: 42ms</span>
             </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Billing Card */}
          <Link href="/dashboard/billing" className="group bg-zinc-900/30 p-10 rounded-[2.5rem] border border-zinc-800 hover:border-blue-500/50 transition-all relative overflow-hidden backdrop-blur-sm shadow-2xl">
            <div className="relative z-10">
              <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Available Credits</p>
              <p className="text-6xl font-black tracking-tighter leading-none mb-8">$0.00</p>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest bg-blue-500/10 text-blue-500 group-hover:bg-blue-500 group-hover:text-black transition-all">
                Add Credits <ArrowUpRight size={14} strokeWidth={3} />
              </div>
            </div>
            <div className="absolute -right-6 -bottom-6 text-zinc-800/20 group-hover:text-blue-500/10 transition-all rotate-12">
               <CreditCard size={180} strokeWidth={1} />
            </div>
          </Link>
          
          {/* Status Card */}
          <Link href="/dashboard/agents" className="group bg-zinc-900/30 p-10 rounded-[2.5rem] border border-zinc-800 hover:border-emerald-500/50 transition-all relative overflow-hidden backdrop-blur-sm shadow-2xl">
            <div className="relative z-10">
              <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Voice AI Status</p>
              <p className="text-6xl font-black tracking-tighter leading-none mb-8 text-emerald-500">Active</p>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-400">
                System Online <TrendingUp size={14} strokeWidth={3} />
              </div>
            </div>
            <div className="absolute -right-6 -bottom-6 text-zinc-800/20 group-hover:text-emerald-500/10 transition-all -rotate-12">
               <Mic2 size={180} strokeWidth={1} />
            </div>
          </Link>

          {/* Management Card */}
          <Link href="/dashboard/admin" className="group bg-zinc-900/30 p-10 rounded-[2.5rem] border border-zinc-800 hover:border-white/20 transition-all relative overflow-hidden backdrop-blur-sm shadow-2xl">
            <div className="relative z-10">
              <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Infrastructure</p>
              <p className="text-6xl font-black tracking-tighter leading-none mb-8 text-zinc-100">Clients</p>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest bg-zinc-800 text-zinc-400 group-hover:bg-white group-hover:text-black transition-all">
                Organizations <ArrowUpRight size={14} strokeWidth={3} />
              </div>
            </div>
            <div className="absolute -right-6 -bottom-6 text-zinc-800/20 group-hover:text-zinc-100/10 transition-all">
               <Users size={180} strokeWidth={1} />
            </div>
          </Link>

        </div>

        {/* Dynamic Background Element */}
        <div className="fixed top-0 right-0 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[120px] -z-10 pointer-events-none"></div>
      </main>
    </div>
  );
}