"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useParams } from "next/navigation";
import { 
  Phone, History, CreditCard, Settings, 
  LayoutDashboard, Loader2, PhoneIncoming,
  Activity, ArrowUpRight, Save, X, PhoneCall
} from "lucide-react";

export default function ClientDashboard() {
  const { id } = useParams();
  const [org, setOrg] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  
  const [updateLoading, setUpdateLoading] = useState(false);
  const [buyLoading, setBuyLoading] = useState(false);
  const [callLoading, setCallLoading] = useState(false);
  const [isCreatingAgent, setIsCreatingAgent] = useState(false);

  const [totalCalls, setTotalCalls] = useState(0);
  const [calls, setCalls] = useState<any[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [testNumber, setTestNumber] = useState("");

  const [showAgentModal, setShowAgentModal] = useState(false);
  const [logoUrl, setLogoUrl] = useState("");
  const [brandColor, setBrandColor] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [newAgent, setNewAgent] = useState({ 
    name: "", 
    role: "", 
    prompt: "", 
    firstMessage: "", 
    voice: "Emma" 
  });

  useEffect(() => {
    async function fetchData() {
      if (!id) return;

      const { data: orgData } = await supabase
        .from("organizations")
        .select("*")
        .eq("id", id)
        .single();

      if (orgData) {
        setOrg(orgData);
        setLogoUrl(orgData.logo_url || "");
        setBrandColor(orgData.brand_color || "#10b981");
        setSystemPrompt(orgData.system_prompt || "");
      }

      const { count } = await supabase
        .from('calls')
        .select('*', { count: 'exact', head: true })
        .eq('org_id', id);
      
      setTotalCalls(count || 0);

      const { data: callLogs } = await supabase
        .from("calls")
        .select("*")
        .eq("org_id", id)
        .order("created_at", { ascending: false });

      if (callLogs) setCalls(callLogs);

      const { data: agentsData } = await supabase
        .from("agents")
        .select("*")
        .eq("org_id", id);
      
      if (agentsData) setAgents(agentsData);

      setLoading(false);
    }
    
    fetchData();
  }, [id]);

  const handleBuyNumber = async () => {
    setBuyLoading(true);
    try {
      const res = await fetch("/api/vapi/buy-number", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orgId: id }),
      });
      const result = await res.json();
      if (res.ok) {
        alert("Success: Phone number purchased!");
        window.location.reload();
      } else {
        alert("Error: " + result.error);
      }
    } catch (err) {
      alert("Connection error");
    } finally {
      setBuyLoading(false);
    }
  };

  const makeCall = async () => {
    if (!testNumber || !org?.vapi_assistant_id) {
      alert("Please select an agent and enter a phone number");
      return;
    }
    setCallLoading(true);
    try {
      const res = await fetch("/api/vapi/make-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          phoneNumber: testNumber, 
          assistantId: org.vapi_assistant_id 
        }),
      });
      const result = await res.json();
      if (result.success) alert("Call started!");
      else alert("Call Error: " + result.error);
    } finally {
      setCallLoading(false);
    }
  };

  const handleLinkAssistant = async (assistantId: string) => {
    if (!assistantId || !org?.vapi_phone_number_id) {
      alert("Error: Phone number or Assistant ID is missing");
      return;
    }
    
    setUpdateLoading(true);
    try {
      const res = await fetch("/api/vapi/link-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          orgId: id, 
          assistantId: assistantId,
          phoneId: org.vapi_phone_number_id 
        }),
      });
      if (res.ok) {
        setOrg({ ...org, vapi_assistant_id: assistantId });
        alert("Success: Agent linked!");
      } else {
        const result = await res.json();
        alert("Error: " + result.error);
      }
    } finally {
      setUpdateLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-white animate-spin" />
    </div>
  );

  if (!org) return <div className="p-10 text-white font-bold">Organization not found.</div>;

  const currentThemeColor = brandColor || "#10b981";

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-800 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3 px-2">
          {org.logo_url ? (
            <img src={org.logo_url} alt="Logo" className="w-8 h-8 object-contain" />
          ) : (
            <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-black text-xs" style={{backgroundColor: currentThemeColor}}>
              {org.name[0]}
            </div>
          )}
          <span className="font-bold text-sm tracking-tight truncate">{org.name}</span>
        </div>

        <nav className="flex flex-col gap-2">
          {[
            { id: "overview", label: "Overview", icon: LayoutDashboard },
            { id: "agents", label: "AI Agents", icon: PhoneIncoming },
            { id: "calls", label: "Call Logs", icon: History },
            { id: "billing", label: "Billing", icon: CreditCard },
            { id: "settings", label: "Settings", icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id ? "bg-zinc-900 text-white" : "text-zinc-500 hover:text-white"
              }`}
            >
              <item.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto relative">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-2xl font-black tracking-tight uppercase">Dashboard</h2>
            <p className="text-zinc-500 text-xs">Real-time Voice AI Analytics</p>
          </div>
        </header>

        {activeTab === "overview" && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <CreditCard className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">Credit Balance</p>
                  <p className="text-2xl font-black">${org.balance || '0.00'}</p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <PhoneIncoming className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">Total Calls</p>
                  <p className="text-2xl font-black">{totalCalls}</p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">Linked Agent</p>
                  <select 
                    value={org?.vapi_assistant_id || ""}
                    onChange={(e) => handleLinkAssistant(e.target.value)}
                    className="w-full bg-black border border-zinc-800 p-2 mt-2 rounded-lg text-xs outline-none focus:border-white transition-all text-white"
                  >
                    <option value="">-- Select Vapi Agent --</option>
                    {agents.map((agent) => (
                      <option key={agent.id} value={agent.vapi_id}>
                        {agent.name || "Unnamed Assistant"}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-3xl">
                  <Phone className="w-5 h-5 mb-4 text-zinc-500" />
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">Active Number</p>
                  <p className="text-xl font-black text-green-500">{org.phone_number || "No Number"}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl p-8">
                    <h3 className="text-sm font-bold mb-4 uppercase flex items-center gap-2">
                        <PhoneCall size={16}/> Direct Test Call
                    </h3>
                    <div className="flex gap-4">
                        <input 
                            type="text" 
                            value={testNumber} 
                            onChange={(e) => setTestNumber(e.target.value)} 
                            placeholder="+123456789" 
                            className="flex-1 bg-black border border-zinc-800 px-4 py-3 rounded-xl text-sm outline-none focus:border-white transition-all" 
                        />
                        <button 
                            onClick={makeCall} 
                            disabled={callLoading} 
                            className="bg-white text-black px-6 py-3 rounded-xl text-xs font-bold uppercase flex items-center gap-2 hover:bg-zinc-200 transition-all"
                        >
                            {callLoading ? <Loader2 size={14} className="animate-spin" /> : "Start Call"}
                        </button>
                    </div>
                </div>

                <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl p-8">
                    <h3 className="text-sm font-bold mb-4 uppercase">Phone Management</h3>
                    <p className="text-zinc-500 text-xs mb-4">
                      No active number? Purchase a new Vapi number instantly.
                    </p>
                    <button 
                        onClick={handleBuyNumber}
                        disabled={buyLoading || !!org.phone_number}
                        className="w-full bg-zinc-800 text-white px-6 py-3 rounded-xl text-xs font-bold uppercase flex items-center justify-center gap-2 hover:bg-zinc-700 disabled:opacity-50 transition-all"
                    >
                        {buyLoading ? (
                          <Loader2 size={14} className="animate-spin" />
                        ) : (
                          "+ Buy New Number"
                        )}
                    </button>
                </div>
            </div>
          </div>
        )}

        {activeTab === "calls" && (
          <div className="bg-zinc-900/40 border border-zinc-800 rounded-3xl overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead className="bg-zinc-900/60 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                <tr>
                  <th className="p-4 border-b border-zinc-800">Status</th>
                  <th className="p-4 border-b border-zinc-800">Date</th>
                  <th className="p-4 border-b border-zinc-800">Duration</th>
                  <th className="p-4 border-b border-zinc-800">Cost</th>
                  <th className="p-4 border-b border-zinc-800">Recording</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {calls.map((call) => (
                  <tr key={call.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/20 transition-all">
                    <td className="p-4 capitalize font-medium">{call.status}</td>
                    <td className="p-4 text-zinc-400">{new Date(call.created_at).toLocaleDateString()}</td>
                    <td className="p-4 font-mono">
                      {Math.floor(call.duration_seconds / 60)}m {call.duration_seconds % 60}s
                    </td>
                    <td className="p-4 font-bold text-green-500">${(call.cost || 0).toFixed(2)}</td>
                    <td className="p-4">
                      {call.recording_url && (
                        <a 
                          href={call.recording_url} 
                          target="_blank" 
                          rel="noreferrer" 
                          className="text-zinc-500 hover:text-white underline text-xs font-bold"
                        >
                          Listen
                        </a>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}